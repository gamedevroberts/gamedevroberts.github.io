=======================================================
Unite 2013: Custom Build Processes with Unity3D
=======================================================
Author: William Roberts - http://www.williamroberts.net
Date:   August 27, 2013
 
Schell Games - http://www.schellgames.com
=======================================================

This demo illustrates all of the concepts discussed during the presentation.  The code base was tested on
both the Windows and OSX platforms. In order to see the demo fully working, you will need to have a valid 
installation of Unity Pro. Note that the 30 day free trial of Pro will temporarily work if you do not
own a license currently.


===================
Directory Structure
===================

Bin            - Contains the built executables (Not included in zip file, see below for details).
Src            - Contains all of the source for the build tools.
ExampleProject - Contains a demo Unity project.


====================
Building The Project
====================

To begin, we must build the codebase. The toolsets listed below are all capable of successfully building
the project. Other tools may work. However, I have only tested building the project with the tools 
listed below.

Visual Studio 2010 Professional
MSBuild - .NET Framework v3.5
Xamarin Studio - v4.0.12 OSX & Windows
MonoDevelop - v2.8.2 OSX & Windows
XBuild - Mono 2.10.9 OSX & Windows


The Visual Studio solution you need to build is located at: Src/CustomBuildProcesses_Unite2013.sln

Example of building the code with MSBuild (Microsoft .NET Framework)
msbuild Src/CustomBuildProcesses_Unite2013.sln

Example of building the code with XBuild (Mono)
xbuild Src/CustomBuildProcesses_Unite2013.sln


===================
Configuration
===================

Before running the project, we may need to make a small configuration change. 

1.) Open "ExampleProject/DemoProject.build" in your favorite text editor.
2.) Locate the MSBUild property named "UnityExecutable".
3.) Modify the Unity path to point to the location the Unity Editor is installed on your machine if needed.

Note that the demo Unity project included with this sample at "ExampleProject/Unity/Project1" was created using
Unity v4.1.3. You may need to recreate this project if using an older version of Unity. Just make sure the contents
of the "Assets" directory are copied over. There is only two c-sharp scripts in the directory and they should be
compatible with all versions of Unity after Unity v3.5.x.


====================
Running The Project
====================

After building the code base, you will notice a new directory named "Bin" at the root of the project structure. The
Bin directory will contain the executables we just built. 

You can either run the executables from the Bin directory manually or via your development studio software of choice. 
Note that you must set the working directory to the location of the executable in order for the demo to function as
expected.


Example of running the application from the command line with the Microsoft .NET Framework:
cd Bin/Debug
BatchBuildCommand.exe

Example of running the application from the command line with the Mono Framework:
cd Bin/Debug
mono BatchBuildCommand.exe


When running from an IDE that "BatchBuildCommand" c-sharp project must be set as the default startup project. 
Otherwise, the IDE will not be able to start up the project.


====================
What Just Happened?
====================

The BatchBuildCommand application will automatically load and build the "ExampleProject/DemoProject.build" MSBuild
project on startup. The project instructs MSBuild to load "UnitExample.MSBuild.Extensions.dll" and execute two tasks.

The first task, MSBuild, is included with MSBuild. It is responsible for instructing the engine to build the specified 
Visual Studio solution. That solution contains a single project named "SimpleExample.csproj". SimpleExample also 
happens to load "UnitExample.MSBuild.Extensions.dll" and utilize a custom task, CopyTask, in the "AfterBuild" target 
to copy the projects output to "ExampleProject/Unity/Project1".

The second task, UnityTask, is another custom task that was custom built for this example. This task starts Unity in 
batch mode, and sends a single parameter to it. During this process, communication between Unity and MSBuild is also 
demonstrated utilizing sockets.
