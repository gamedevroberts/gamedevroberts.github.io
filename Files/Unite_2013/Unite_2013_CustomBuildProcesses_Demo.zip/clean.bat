@echo off
REM Simple script to fully clean out the project for distibution.

set WorkingDir=%~dp0

REM Make sure we are in the same directory as the bat file.
pushd %WorkingDir%

rmdir /S /Q Bin
rmdir /S /Q Src\BatchBuildCommand\obj
rmdir /S /Q Src\UniteExample.MSBuild.Extensions\obj
rmdir /S /Q ExampleProject\Code\SimpleExample\bin
rmdir /S /Q ExampleProject\Code\SimpleExample\obj
rmdir /S /Q ExampleProject\Unity\Project1\Library
rmdir /S /Q ExampleProject\Unity\Project1\Temp
rmdir /S /Q ExampleProject\Unity\Project1\obj
rmdir /S /Q ExampleProject\Unity\Project1\Assets\Lib

del /S /Q Src\*.suo
del /S /Q Src\*.userprefs
del /S /Q Src\*.sln.cache
del /S /Q Src\BatchBuildCommand\*.pidb
del /S /Q Src\UniteExample.MSBuild.Extensions\*.pidb

del /S /Q ExampleProject\*.suo
del /S /Q ExampleProject\*.userprefs
del /S /Q ExampleProject\*.sln.cache
del /S /Q ExampleProject\Code\*.userprefs
del /S /Q ExampleProject\Code\*.sln.cache
del /S /Q ExampleProject\Code\*.pidb

popd
pause