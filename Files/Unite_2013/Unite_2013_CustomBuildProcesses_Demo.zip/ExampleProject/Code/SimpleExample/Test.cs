﻿
namespace SimpleExample
{
    public static class Test
    {
        public static string GetMessage()
        {
            return "Hello from the copied assembly!";
        }
    }
}
